import { NextResponse } from "next/server";
import { verifyNowPaymentsSignature } from "@/lib/nowpayments";
import { supabaseAdmin } from "@/lib/supabase";
import { getPlan } from "@/lib/plans";
import { encryptJson } from "@/lib/crypto";
import { provisionProxy } from "@/lib/veritasproxy";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let payload: Record<string, unknown>;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const signature = request.headers.get("x-nowpayments-sig");
  if (!verifyNowPaymentsSignature(payload, signature)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const orderId = typeof payload.order_id === "string" ? payload.order_id : "";
  const paymentStatus = typeof payload.payment_status === "string" ? payload.payment_status : "";
  if (!orderId) return NextResponse.json({ error: "Missing order ID" }, { status: 400 });

  const db = supabaseAdmin();
  const { data: order, error } = await db.from("orders").select("*").eq("id", orderId).maybeSingle();
  if (error) return NextResponse.json({ error: "Database lookup failed" }, { status: 500 });
  if (!order) return NextResponse.json({ ok: true });

  // Ignore duplicate or non-final events. Only a completed payment may trigger fulfilment.
  if (order.status === "fulfilled") return NextResponse.json({ ok: true });
  if (paymentStatus === "failed" || paymentStatus === "expired") {
    await db.from("orders").update({ status: paymentStatus }).eq("id", orderId);
    return NextResponse.json({ ok: true });
  }
  if (paymentStatus !== "finished") return NextResponse.json({ ok: true });

  const expectedAmount = Number(order.amount_usd);
  const receivedAmount = Number(payload.price_amount ?? payload.actually_paid ?? 0);
  const receivedCurrency = String(payload.price_currency ?? "").toLowerCase();
  if (!Number.isFinite(receivedAmount) || Math.abs(receivedAmount - expectedAmount) > 0.01 || receivedCurrency !== "usd") {
    await db.from("orders").update({ status: "payment_review" }).eq("id", orderId);
    return NextResponse.json({ ok: true });
  }

  // Claim the order atomically to reduce duplicate fulfilment on concurrent callbacks.
  const { data: claimed } = await db.from("orders").update({ status: "provisioning" })
    .eq("id", orderId).in("status", ["awaiting_payment", "payment_pending"]).select("id").maybeSingle();
  if (!claimed) return NextResponse.json({ ok: true });

  try {
    const plan = getPlan(order.plan_slug);
    if (!plan) throw new Error("Unknown plan slug");
    const proxy = await provisionProxy(plan, orderId);
    const { error: saveError } = await db.from("orders").update({
      status: "fulfilled",
      provider_plan_id: proxy.providerPlanId,
      credentials_encrypted: encryptJson(proxy),
      fulfilled_at: new Date().toISOString()
    }).eq("id", orderId);
    if (saveError) throw saveError;
  } catch (e) {
    console.error("proxy_provisioning_error", orderId, e);
    await db.from("orders").update({ status: "provisioning_failed" }).eq("id", orderId);
    // Return 200 to avoid blind repeated processing; reconcile and retry manually using the same supplier idempotency key.
  }
  return NextResponse.json({ ok: true });
}