import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { decryptJson, hashToken } from "@/lib/crypto";

export const runtime = "nodejs";

type ProxyData = {
  type: string; host: string; port: number; username: string; password: string;
  proxyUrl?: string; bandwidthGb: number; status: string;
};

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const token = new URL(request.url).searchParams.get("token") ?? "";
    if (!token || token.length < 30) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const db = supabaseAdmin();
    const { data: order, error } = await db.from("orders").select("id,status,plan_slug,amount_usd,customer_email,access_token_hash,credentials_encrypted,created_at,fulfilled_at").eq("id", id).maybeSingle();
    if (error || !order || hashToken(token) !== order.access_token_hash) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    const result: Record<string, unknown> = {
      orderId: order.id, status: order.status, plan: order.plan_slug,
      amountUsd: order.amount_usd, createdAt: order.created_at, fulfilledAt: order.fulfilled_at
    };
    if (order.status === "fulfilled" && order.credentials_encrypted) {
      result.proxy = decryptJson<ProxyData>(order.credentials_encrypted);
    }
    return NextResponse.json(result, { headers: { "Cache-Control": "no-store, private" } });
  } catch (e) {
    console.error("order_status_error", e);
    return NextResponse.json({ error: "Could not retrieve order status." }, { status: 500 });
  }
}