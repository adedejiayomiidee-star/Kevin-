 "use client";
import { useState } from "react";
import { PLANS } from "@/lib/plans";

export default function Home() {
  const [selected, setSelected] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [coin, setCoin] = useState("usdttrc20");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [invoiceUrl, setInvoiceUrl] = useState("");
  const [orderAccessUrl, setOrderAccessUrl] = useState("");

  async function checkout() {
    if (!selected) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/checkout", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planSlug: selected, email, payCurrency: coin })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not start checkout.");
      setInvoiceUrl(data.invoiceUrl);
      setOrderAccessUrl(data.orderAccessUrl);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Checkout is not configured yet.");
      setBusy(false);
    }
  }

  return <main>
    <header className="wrap nav">
      <a className="brand" href="/">Proxy<span>Harbor</span></a>
      <nav className="navlinks"><a href="#plans">Plans</a><a href="#how">How it works</a><a href="#safety">Responsible use</a></nav>
      <a className="btn" href="#plans">Shop proxies ↗</a>
    </header>
    <section className="wrap hero">
      <div>
        <div className="eyebrow">Residential & datacenter proxy access</div>
        <h1>Proxy access.<br/>Without the guesswork.</h1>
        <p>Straightforward proxy plans for permitted research, localization checks, QA testing, and regional website testing. Choose a plan, pay with supported crypto, and manage access securely.</p>
        <div className="actions"><a className="btn primary" href="#plans">Explore plans ↘</a><a className="btn" href="#how">How it works</a></div>
        <p className="fine">No promises of anonymity or guaranteed access. Availability depends on supplier coverage and applicable terms.</p>
      </div>
      <div className="hero-card">
        <div className="status"><span className="dot"/> Simple, secure proxy delivery</div>
        <div className="terminal"><div><span className="green">$</span> choose_plan --type residential</div><div><span className="green">✓</span> plan selected</div><div><span className="green">✓</span> payment confirmation required</div><div><span className="green">✓</span> credentials released after fulfilment</div><br/><div style={{color:"#7184a6"}}>// Example workflow — supplier connection required</div></div>
        <div className="metrics"><div className="metric"><strong>3</strong><span>starter plans</span></div><div className="metric"><strong>Crypto</strong><span>checkout option</span></div><div className="metric"><strong>24/7</strong><span>online storefront</span></div></div>
      </div>
    </section>
    <section className="wrap section" id="plans">
      <div className="eyebrow">Choose your access</div><h2>Plans that stay simple.</h2>
      <p className="sub">Prices below are starter retail prices in USD. Before accepting live orders, confirm supplier cost, payment fees, and supported coin networks in your own accounts.</p>
      <div className="plans">{PLANS.map(p=><article className={`plan ${p.featured?"featured":""}`} key={p.slug}>
        <div className="pill">{p.category}{p.featured?" · Popular":""}</div><h3>{p.name}</h3><p>{p.description}</p>
        <div className="price">${p.priceUsd.toFixed(2)} <small>/ plan</small></div>
        <ul><li>Secure checkout flow</li><li>Plan-specific credentials after payment</li><li>Customer support and usage rules</li></ul>
        <button className={`btn ${p.featured?"primary":""}`} onClick={()=>{setSelected(p.slug);setMessage("");}}>Choose plan →</button>
      </article>)}</div>
      <p className="fine">Prices are editable in <code>lib/plans.ts</code>. Do not publish prices until you have confirmed supplier costs and fulfilment availability.</p>
    </section>
    <section className="wrap section" id="how">
      <div className="eyebrow">A clear process</div><h2>From checkout to connection.</h2>
      <div className="features">
        <article className="feature"><div className="icon">01</div><h3>Choose a plan</h3><p>Select residential or datacenter access that matches your permitted use and traffic needs.</p></article>
        <article className="feature"><div className="icon">02</div><h3>Pay securely</h3><p>The checkout creates a hosted crypto invoice. The server waits for a verified payment notification before fulfilment.</p></article>
        <article className="feature"><div className="icon">03</div><h3>Receive access</h3><p>When the payment and supplier integration are correctly configured, the order can be provisioned and its status checked.</p></article>
      </div>
    </section>
    <section className="wrap section" id="safety">
      <div className="eyebrow">Trust & safety</div><h2>Built for responsible use.</h2>
      <div className="notice">ProxyHarbor prohibits unlawful activity, fraud, account takeover, unauthorized access, harassment, and attempts to evade security controls. Customers must comply with applicable law and the proxy supplier’s terms. We may suspend access or request information when needed to investigate abuse.</div>
      <p className="sub">Before launch, add a monitored support email, review refund and privacy policies, verify supplier reseller approval, and test the full payment-to-delivery flow. The starter code does not replace legal or security review.</p>
    </section>
    <footer className="wrap footer"><div>© {new Date().getFullYear()} ProxyHarbor. All rights reserved.</div><div className="footerlinks"><a href="/terms">Terms</a><a href="/privacy">Privacy</a><a href="/refunds">Refunds</a><a href="mailto:support@example.com">Support</a></div></footer>
    <div className={`checkout ${selected?"open":""}`} role="dialog" aria-modal="true" aria-label="Checkout">
      <div className="modal"><button className="close" aria-label="Close" onClick={()=>{setSelected(null);setMessage("");setInvoiceUrl("");setOrderAccessUrl("");}}>×</button>
        <div className="eyebrow">Secure checkout</div><h2>Finish your order</h2><p className="fine">We’ll send you to the payment provider’s hosted invoice. Never send crypto to an address supplied in chat or by a stranger.</p>
        <label htmlFor="email">Email address</label><input id="email" type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)}/>
        <label htmlFor="coin">Pay with</label><select id="coin" value={coin} onChange={e=>setCoin(e.target.value)}><option value="usdttrc20">USDT (TRON / TRC20)</option><option value="usdtbsc">USDT (BSC / BEP20)</option><option value="btc">Bitcoin (BTC)</option><option value="eth">Ethereum (ETH)</option></select>
        {!invoiceUrl && <button className="btn primary" disabled={busy||!email.includes("@")} onClick={checkout}>{busy?"Preparing invoice…":"Create payment invoice"}</button>}
        {invoiceUrl && <div className="msg"><strong>Invoice created.</strong><br/>Keep your private order link below, then open the hosted invoice in a new tab.<br/><a className="btn primary" style={{width:"100%",marginTop:12}} href={invoiceUrl} target="_blank" rel="noreferrer">Open crypto payment invoice ↗</a><a className="btn" style={{width:"100%",marginTop:10}} href={orderAccessUrl} target="_blank" rel="noreferrer">Save private order status link ↗</a><span className="fine" style={{display:"block",marginTop:10}}>Save this private order link. Anyone who has it may be able to view this order, so do not share it.</span></div>}
        {message&&<div className="msg" role="alert">{message}</div>}
        <p className="fine">Only select a network that is enabled in the merchant account. A payment on the wrong network may be unrecoverable.</p>
      </div>
    </div>
  </main>;
}