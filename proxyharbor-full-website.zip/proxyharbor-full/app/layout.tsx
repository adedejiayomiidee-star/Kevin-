import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ProxyHarbor — Proxy access made simple",
  description: "Residential and datacenter proxy plans for permitted research, localization testing, and software QA."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}