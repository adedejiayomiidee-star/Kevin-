create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_email text not null,
  plan_slug text not null,
  amount_usd numeric(10,2) not null check (amount_usd > 0),
  pay_currency text not null,
  status text not null default 'awaiting_payment' check (status in (
    'awaiting_payment','payment_pending','payment_review','provisioning',
    'fulfilled','failed','expired','checkout_error','provisioning_failed'
  )),
  payment_invoice_id text unique,
  payment_invoice_url text,
  provider_plan_id text,
  access_token_hash text not null,
  request_ip_hash text,
  credentials_encrypted text,
  created_at timestamptz not null default now(),
  fulfilled_at timestamptz
);

create index if not exists orders_status_created_idx on public.orders(status, created_at desc);
create index if not exists orders_customer_email_idx on public.orders(customer_email);

alter table public.orders enable row level security;

-- Intentionally no client-facing RLS policies. Browser access is only through
-- server routes that use the service role and validate the random access token.
-- Never expose SUPABASE_SERVICE_ROLE_KEY in NEXT_PUBLIC_* variables.

create table if not exists public.webhook_events (
  id bigserial primary key,
  provider text not null,
  event_key text not null,
  received_at timestamptz not null default now(),
  unique(provider, event_key)
);
