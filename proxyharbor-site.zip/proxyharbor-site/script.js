document.getElementById("year").textContent = new Date().getFullYear();
const toast = document.getElementById("toast");
let toastTimer;
document.querySelectorAll("[data-plan]").forEach((button) => {
  button.addEventListener("click", () => {
    const plan = button.dataset.plan;
    const price = button.dataset.price;
    toast.textContent = `${plan} selected ($${price} demo price). Checkout is not live yet—supplier and secure crypto payment integration must be configured first.`;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 5000);
  });
});