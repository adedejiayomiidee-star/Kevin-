# ProxyHarbor demo storefront

A responsive front-end prototype for a proxy reseller offering residential and datacenter plans.

## Preview
Open `index.html` in a browser. No build tools are needed for the static demo.

## Included
- Responsive landing page
- Residential and datacenter plan cards
- USD demo prices
- USDT/BTC/ETH checkout concept
- Responsible-use messaging
- Clear notice that checkout is not live

## Not yet live
This prototype does not collect payments, create customer accounts, issue proxy credentials, or call any supplier API. The plan buttons only show a demo notice.

## To launch for real
1. Register with a proxy supplier that explicitly permits resale and provides an API.
2. Select a crypto processor that supports your business location and required coins/networks.
3. Implement sign-in and a database with customer-scoped access.
4. Create orders server-side; calculate prices on the server.
5. Verify payment webhooks using the processor's current signature rules and deduplicate events.
6. Provision through the supplier API only after confirmed payment.
7. Encrypt proxy credentials at rest and expose them only to the matching signed-in customer.
8. Add admin controls, support, terms, privacy, refund rules, rate limits, monitoring, and abuse handling.
9. Test payment underpayments, duplicate webhooks, failed provisioning, refunds, and supplier outages before launch.

Never store secrets in client-side JavaScript or commit API keys.
