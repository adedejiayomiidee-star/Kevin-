const plans = [
  { id: "resi-5gb", name: "Residential Starter", type: "Residential", description: "5 GB traffic · rotating residential access", price: "$—", note: "Price configured after supplier quote" },
  { id: "dc-5ip", name: "Datacenter Starter", type: "Datacenter", description: "5 IPs · monthly access", price: "$—", note: "Price configured after supplier quote" },
];

export default function Home() {
  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: "48px 20px", fontFamily: "Arial, sans-serif" }}>
      <nav style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16 }}>
        <strong style={{ fontSize: 22 }}>ProxyHarbor</strong>
        <a href="#plans">View plans</a>
      </nav>
      <section style={{ padding: "72px 0 44px" }}>
        <p style={{ color: "#2563eb", fontWeight: 700 }}>RESIDENTIAL + DATACENTER</p>
        <h1 style={{ fontSize: "clamp(36px, 6vw, 58px)", lineHeight: 1.05, marginBottom: 16 }}>
          Proxy access, clearly priced and easy to manage.
        </h1>
        <p style={{ maxWidth: 640, color: "#555", fontSize: 18, lineHeight: 1.6 }}>
          Reliable proxy access for authorized research, localization checks, software testing,
          and other permitted uses. Pay with supported cryptocurrency and manage access in one place.
        </p>
        <a href="#plans" style={{ display: "inline-block", marginTop: 18, padding: "13px 18px", background: "#111827", color: "white", borderRadius: 10, textDecoration: "none" }}>
          Explore plans
        </a>
      </section>
      <section id="plans">
        <h2>Starter plans</h2>
        <p style={{ color: "#666" }}>Illustrative plan descriptions only. Set final prices after checking supplier cost, network fees, and support costs.</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 18, marginTop: 20 }}>
          {plans.map((plan) => (
            <article key={plan.id} style={{ border: "1px solid #ddd", borderRadius: 16, padding: 22 }}>
              <p style={{ color: "#2563eb", fontWeight: 700 }}>{plan.type}</p>
              <h3>{plan.name}</h3>
              <p>{plan.description}</p>
              <h2>{plan.price}</h2>
              <p style={{ fontSize: 13, color: "#666" }}>{plan.note}</p>
              <button disabled style={{ padding: "11px 14px", borderRadius: 8, border: 0, background: "#ddd" }}>
                Checkout setup required
              </button>
            </article>
          ))}
        </div>
      </section>
      <section style={{ marginTop: 48, padding: 22, background: "#f5f7fb", borderRadius: 14 }}>
        <h2>Responsible use</h2>
        <p>Customers must follow applicable law, supplier terms, and website acceptable-use rules. Abuse, fraud, account takeover, and unauthorized access are prohibited.</p>
      </section>
      <footer style={{ marginTop: 40, borderTop: "1px solid #ddd", paddingTop: 20, color: "#666", fontSize: 13 }}>
        © {new Date().getFullYear()} ProxyHarbor · Contact · Terms · Privacy · Refunds
      </footer>
    </main>
  );
}
