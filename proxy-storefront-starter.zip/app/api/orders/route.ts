import { NextResponse } from "next/server";

/**
 * SECURITY NOTE:
 * This endpoint is intentionally a stub. Before enabling checkout:
 * - require a signed-in user (Supabase server auth)
 * - look up product and price on the server, not from request JSON
 * - create a pending order in the database
 * - create a crypto invoice using the payment processor
 * - save provider invoice/payment IDs
 * - return only the hosted invoice URL and public order reference
 */
export async function POST() {
  return NextResponse.json(
    { error: "Checkout is not configured yet. Configure auth, database, and payment provider first." },
    { status: 501 }
  );
}
