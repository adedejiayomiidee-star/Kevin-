import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ProxyHarbor | Proxy Access",
  description: "Residential and datacenter proxy access for permitted use cases.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body style={{ margin: 0 }}>{children}</body></html>;
}
