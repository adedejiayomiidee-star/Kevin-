-- Run in Supabase SQL Editor. Review and adapt before production.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  category text not null check (category in ('residential', 'datacenter')),
  description text not null default '',
  price_usd numeric(12,2) not null check (price_usd >= 0),
  active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  product_id uuid not null references public.products(id),
  amount_usd numeric(12,2) not null check (amount_usd >= 0),
  status text not null default 'pending'
    check (status in ('pending','payment_confirmed','provisioning','fulfilled','failed','refunded')),
  payment_provider text,
  payment_id text unique,
  payment_status text,
  provider_package_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Keep credentials in a separate table and do not grant direct client access.
create table if not exists public.proxy_credentials (
  id uuid primary key default gen_random_uuid(),
  order_id uuid unique not null references public.orders(id) on delete cascade,
  provider_package_id text not null,
  host text not null,
  port integer not null,
  username text not null,
  password_ciphertext text not null,
  expires_at timestamptz,
  traffic_limit_gb numeric(12,3),
  created_at timestamptz not null default now()
);

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider_event_id text unique not null,
  order_id uuid references public.orders(id),
  event_status text not null,
  received_at timestamptz not null default now(),
  processed_at timestamptz
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.proxy_credentials enable row level security;
alter table public.payment_events enable row level security;

-- Public can see active product catalogue only.
create policy "Anyone can read active products"
on public.products for select
using (active = true);

-- Customers can read only their own orders. Inserts/updates should go through trusted server code.
create policy "Customers read own orders"
on public.orders for select to authenticated
using (auth.uid() = user_id);

-- No client policies on credentials or payment_events by design.
-- Use server-side service role only, and never expose SUPABASE_SERVICE_ROLE_KEY publicly.
