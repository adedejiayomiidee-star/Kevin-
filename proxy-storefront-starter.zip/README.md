# Proxy Storefront Starter (MVP)

A starter architecture for a legitimate residential + datacenter proxy reseller.
This is a scaffold, not a production-ready store. It intentionally does not provision
proxies or mark payments paid until provider credentials, webhook signature verification,
and database policies have been configured and tested.

## Stack
- Next.js App Router + TypeScript
- Supabase (Auth + Postgres)
- Crypto payment processor (example: NOWPayments)
- Proxy reseller provider adapter (example: RedScrape reseller API)

## Start
1. Install Node.js 20.9+.
2. Run: `npx create-next-app@latest proxy-storefront --ts --app`
3. Copy these starter files into the created project (merge `app/` and `lib/`).
4. Install: `npm install @supabase/supabase-js`
5. Copy `.env.example` to `.env.local` and fill values.
6. Run the SQL in `supabase/schema.sql` in Supabase SQL Editor.
7. Start with `npm run dev`.

## Required before live launch
- Configure Supabase Auth and strict Row Level Security.
- Add authenticated checkout; never trust a client-supplied price or user ID.
- Implement the payment provider's exact webhook signature verification per current docs.
- Persist provider event IDs and process events idempotently.
- Only provision after verified, fully confirmed payment.
- Store proxy credentials encrypted or in a secrets vault; never expose supplier keys.
- Add rate limits, abuse reporting, refund policy, privacy policy, terms, logging, and admin access controls.
- Confirm supplier reseller approval, product availability, acceptable-use terms, and working capital.
- Test underpayment, duplicate webhooks, delayed confirmations, failed provisioning, refunds, and provider downtime.

## Important
No API keys belong in frontend code or Git. Do not use the demo product prices as real supplier prices.
