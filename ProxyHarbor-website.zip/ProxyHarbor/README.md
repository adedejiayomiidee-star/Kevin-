# ProxyHarbor

A responsive, static landing-page starter for ProxyHarbor, built with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive dark theme and layout
- `script.js` — mobile navigation and current year

## Run locally
Open `index.html` in a browser.

## Publish
Upload these files to a GitHub repository. To publish with GitHub Pages, open the repository's **Settings → Pages**, select **Deploy from a branch**, choose the default branch and `/ (root)` folder, and save.

## Customize
Replace placeholder copy and add your own verified service links, contact information, privacy policy, and terms before launching publicly.

## Note
This is a static front-end template. It does not provide a proxy server, anonymization service, authentication, payments, or a backend.
