# ProxyHarbor

A polished, responsive static website starter about proxy technology, online privacy basics, and informed browsing choices.

## Files
- `index.html` — page content and accessible navigation
- `style.css` — responsive visual design and mobile layout
- `script.js` — mobile menu, keyboard handling, and current year
- `favicon.svg` — browser tab icon

## Preview
Open `index.html` in a modern browser.

## Publish on GitHub Pages
1. Upload the project files to the root of your GitHub repository.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select your default branch (often `main`) and the `/ (root)` folder, then save.
5. Wait for GitHub Pages to publish and use the URL shown in Settings → Pages.

## Customize before launch
- Replace the sample copy with your own accurate product details.
- Add verified links, contact details, and privacy/legal pages if needed.
- Test the site on mobile and desktop.

## Important scope note
This project is a static informational front end. It does not provide working proxy connections, proxy servers, accounts, payment processing, or a backend. Those features require separate infrastructure and security review.
